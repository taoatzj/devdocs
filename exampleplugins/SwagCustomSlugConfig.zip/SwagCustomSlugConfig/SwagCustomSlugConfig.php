<?php

namespace SwagCustomSlugConfig;

use Shopware\Components\Plugin;

class SwagCustomSlugConfig extends Plugin
{
}